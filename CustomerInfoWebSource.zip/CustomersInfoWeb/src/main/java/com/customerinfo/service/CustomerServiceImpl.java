package com.customerinfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.customerinfo.dao.CustomerDao;
import com.customerinfo.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerDao customerDao;
	
	@Transactional
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerDao.addCustomer(customer);
	}

	@Transactional
	public void editCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerDao.editCustomer(customer);
	}

	@Transactional
	public void deleteCustomer(int custId) {
		// TODO Auto-generated method stub
		customerDao.deleteCustomer(custId);
	}

	@Transactional
	public Customer getCustomer(int custId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomerById(custId);
	}

	@Transactional
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomer();
	}

	@Transactional
	public List<Customer> getCustomer(String customerName) {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(customerName);
	}

	@Transactional
	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomerById(customerId);
	}

}
