package com.customerinfo.customervalidator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.customerinfo.model.Customer;

@Component("customerFormValidator")
public class CustomerFormValidator {
	
	@SuppressWarnings("unchecked")
	public boolean supports(Class clazz){
		return Customer.class.isAssignableFrom(clazz);
	}
	
	public void validate(Object model, Errors errors)
	{
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "customerFName","required.name", "Name is required.");
	}

}
