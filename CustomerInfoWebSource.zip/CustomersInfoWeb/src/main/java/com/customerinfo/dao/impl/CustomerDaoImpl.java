/**
 * 
 */
package com.customerinfo.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.customerinfo.dao.CustomerDao;
import com.customerinfo.model.Customer;

/**
 * @author mon08
 *
 */
@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	/* (non-Javadoc)
	 * @see com.customerinfo.dao.CustomerDao#addCustomer(com.customerinfo.model.Customer)
	 */
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(customer);
	}

	/* (non-Javadoc)
	 * @see com.customerinfo.dao.CustomerDao#editCustomer(com.customerinfo.model.Customer)
	 */
	public void editCustomer(Customer customer) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(customer);
	}

	/* (non-Javadoc)
	 * @see com.customerinfo.dao.CustomerDao#deleteCustomer(int)
	 */
	public void deleteCustomer(int custId) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(getCustomerById(custId));
	}

	/* (non-Javadoc)
	 * @see com.customerinfo.dao.CustomerDao#getAllCustomer()
	 */
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from Customer").list();
	}

	public List<Customer> getCustomer(String customer) {
		// TODO Auto-generated method stub
		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Customer.class);
		criteria.add(Restrictions.ilike("customerFName", customer+"%"));
		return criteria.list();
	}

	@Override
	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		 return (Customer) sessionFactory.getCurrentSession().get(Customer.class, customerId);
	}
}
