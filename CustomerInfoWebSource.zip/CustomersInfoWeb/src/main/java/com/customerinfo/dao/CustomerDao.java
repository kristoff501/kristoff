package com.customerinfo.dao;

import java.util.List;

import com.customerinfo.model.Customer;

public interface CustomerDao {
	public void addCustomer(Customer customer);
	public void editCustomer(Customer customer);
	public void deleteCustomer(int custId);
	public List<Customer> getCustomer(String customerName);
	public Customer getCustomerById(int customerId);
	public List<Customer> getAllCustomer();
}
