package com.customerinfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.customerinfo.customervalidator.CustomerFormValidator;
import com.customerinfo.model.Customer;
import com.customerinfo.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CustomerFormValidator validator;
	
	@RequestMapping("/home")
	public String home()
	{
		return "home";
	}
	

	@RequestMapping("/searchCustomers")
	public ModelAndView searchCustomers(@RequestParam(required= false, defaultValue="") String name)
	{
		ModelAndView mav = new ModelAndView("showCustomers");
		List<Customer> customers = (List<Customer>) customerService.getCustomer(name.trim());
		mav.addObject("SEARCH_CONTACTS_RESULTS_KEY", customers);
		return mav;
	}
	
	@RequestMapping("/viewAllCustomers")
	public ModelAndView getAllCustomers()
	{
		ModelAndView mav = new ModelAndView("showCustomers");
		List<Customer> customers = customerService.getAllCustomer();
		mav.addObject("SEARCH_CONTACTS_RESULTS_KEY", customers);
		return mav;
	}
	
	@RequestMapping(value="/newCustomer", method=RequestMethod.GET)
	public ModelAndView newuserForm()
	{
		ModelAndView mav = new ModelAndView("newCustomer");
		Customer customer = new Customer();
		mav.getModelMap().put("newCustomer", customer);
		return mav;
	}
	
	@RequestMapping(value="/saveCustomer", method=RequestMethod.POST)
	public String create(@ModelAttribute("newCustomer")Customer customer, BindingResult result, SessionStatus status)
	{
		validator.validate(customer, result);
		if (result.hasErrors()) 
		{				
			return "newCustomer";
		}
		customerService.addCustomer(customer);
		status.setComplete();
		return "redirect:viewAllCustomers.do";
	}
	
	@RequestMapping(value="/updateCustomer", method=RequestMethod.GET)
	public ModelAndView edit(@RequestParam("id")Integer id)
	{
		ModelAndView mav = new ModelAndView("editCustomer");
		Customer customer = customerService.getCustomerById(id);
		mav.addObject("editCustomer", customer);
		return mav;
	}
	
	@RequestMapping(value="/updateCustomer", method=RequestMethod.POST)
	public String update(@ModelAttribute("editContact") Customer customer, BindingResult result, SessionStatus status)
	{
		validator.validate(customer, result);
		if (result.hasErrors()) {
			return "editCustomer";
		}
		customerService.editCustomer(customer);
		status.setComplete();
		return "redirect:viewAllCustomers.do";
	}
	
	
	@RequestMapping("deleteCustomer")
	public ModelAndView delete(@RequestParam("id")Integer id)
	{
		ModelAndView mav = new ModelAndView("redirect:viewAllCustomers.do");
		customerService.deleteCustomer(id);
		return mav;
	}
}
