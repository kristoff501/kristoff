package com.customerinfo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	@Column
	private String customerFName;
	@Column
	private String customerLName;
	@Column
	private String phoneNumber;
	@Column
	private String emailAddress;
	@Column
	private String address;
	
	
	public Customer(){}
	
	public Customer(String customerFName, String customerLName, String phoneNumber, String emailAddress,  String address){
		this.customerFName = customerFName;
		this.customerLName = customerLName;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		
	}

	/**
	 * @return the customerId
	 */
	public int getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerFName
	 */
	public String getCustomerFName() {
		return customerFName;
	}

	/**
	 * @param customerFName the customerFName to set
	 */
	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	/**
	 * @return the customerLName
	 */
	public String getCustomerLName() {
		return customerLName;
	}

	/**
	 * @param customerLName the customerLName to set
	 */
	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the address1
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
}
